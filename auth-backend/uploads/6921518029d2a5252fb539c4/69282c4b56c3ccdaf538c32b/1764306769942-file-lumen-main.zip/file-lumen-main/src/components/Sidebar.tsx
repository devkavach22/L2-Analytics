import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { 
  ChevronLeft, 
  ChevronRight,
  LayoutDashboard, 
  FolderOpen, 
  Settings, 
  FileText,
  User,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isAdmin?: boolean;
  onLogout?: () => void;
}

export const Sidebar = ({ isAdmin = false, onLogout }: SidebarProps) => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const menuItems = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      href: isAdmin ? "/admin" : "/dashboard",
    },
    {
      title: "Tools",
      icon: FileText,
      href: "/tools",
    },
    {
      title: "Files",
      icon: FolderOpen,
      href: "/files",
    },
    {
      title: "Profile",
      icon: User,
      href: "/profile",
    },
    {
      title: "Settings",
      icon: Settings,
      href: "/settings",
    },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <aside
      className={cn(
        "fixed left-0 top-16 h-[calc(100vh-4rem)] bg-card border-r border-border transition-all duration-300 z-40 shadow-lg",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Toggle Button */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-3 top-4 h-6 w-6 rounded-full border border-border bg-background shadow-md hover:bg-muted z-50"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? (
          <ChevronRight className="h-4 w-4" />
        ) : (
          <ChevronLeft className="h-4 w-4" />
        )}
      </Button>

      {/* Menu Items */}
      <nav className="p-4 space-y-2">
        {menuItems.map((item) => (
          <Link key={item.href} to={item.href}>
            <div
              className={cn(
                "group flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 relative",
                isActive(item.href)
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "hover:bg-muted text-muted-foreground hover:text-foreground"
              )}
            >
              <item.icon className="h-5 w-5 flex-shrink-0" />
              <span
                className={cn(
                  "font-medium transition-all duration-300",
                  collapsed ? "opacity-0 w-0" : "opacity-100 w-auto"
                )}
              >
                {item.title}
              </span>
              
              {/* Tooltip on hover when collapsed */}
              {collapsed && (
                <div className="absolute left-full ml-2 px-3 py-2 bg-secondary text-secondary-foreground rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50">
                  {item.title}
                </div>
              )}
            </div>
          </Link>
        ))}

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className={cn(
            "group w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 relative hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
          )}
        >
          <LogOut className="h-5 w-5 flex-shrink-0" />
          <span
            className={cn(
              "font-medium transition-all duration-300",
              collapsed ? "opacity-0 w-0" : "opacity-100 w-auto"
            )}
          >
            Logout
          </span>
          
          {/* Tooltip on hover when collapsed */}
          {collapsed && (
            <div className="absolute left-full ml-2 px-3 py-2 bg-secondary text-secondary-foreground rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50">
              Logout
            </div>
          )}
        </button>
      </nav>
    </aside>
  );
};
