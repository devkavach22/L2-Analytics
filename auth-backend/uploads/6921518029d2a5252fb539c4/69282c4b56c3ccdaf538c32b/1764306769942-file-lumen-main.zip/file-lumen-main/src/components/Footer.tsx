import { Link } from "react-router-dom";
import { Facebook, Twitter, Linkedin } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground py-12 border-t border-border">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="font-bold text-lg">Products</h3>
            <ul className="space-y-2">
              <li><Link to="/tools" className="text-sm hover:text-primary transition-colors">Beans</Link></li>
              <li><Link to="/tools" className="text-sm hover:text-primary transition-colors">New in</Link></li>
              <li><Link to="/tools" className="text-sm hover:text-primary transition-colors">Weekly box</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Category</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Men</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Woman</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Company Info</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm hover:text-primary transition-colors">About us</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Contact us</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Payment options</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Track Order</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Support</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Vouchers</a></li>
              <li><a href="#" className="text-sm hover:text-primary transition-colors">Site Charts</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Follow us</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border/30 flex flex-wrap justify-center gap-6 text-sm">
          <a href="#" className="hover:text-primary transition-colors">Data settings</a>
          <a href="#" className="hover:text-primary transition-colors">Cookie settings</a>
          <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-primary transition-colors">Terms And Conditions</a>
          <a href="#" className="hover:text-primary transition-colors">Imprint</a>
        </div>

        <div className="mt-6">
          <p className="text-center text-sm opacity-75">
            © 2024 Kavach PDF. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
