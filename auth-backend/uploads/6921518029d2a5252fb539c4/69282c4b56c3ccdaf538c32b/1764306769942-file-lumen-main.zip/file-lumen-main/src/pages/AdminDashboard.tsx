import { Header } from "@/components/Header";
import { Sidebar } from "@/components/Sidebar";
import { Footer } from "@/components/Footer";
import { KPICard } from "@/components/KPICard";
import { Users, FileText, Activity, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const kpiData = [
  {
    title: "Total Users",
    value: "2,543",
    icon: Users,
    trend: { value: 12.5, isPositive: true }
  },
  {
    title: "Documents Processed",
    value: "15,432",
    icon: FileText,
    trend: { value: 8.2, isPositive: true }
  },
  {
    title: "Active Sessions",
    value: "342",
    icon: Activity,
    trend: { value: 3.1, isPositive: false }
  },
  {
    title: "Monthly Growth",
    value: "24%",
    icon: TrendingUp,
    trend: { value: 5.4, isPositive: true }
  }
];

const recentUsers = [
  { id: 1, name: "John Doe", email: "john@example.com", status: "active", joined: "2024-01-15" },
  { id: 2, name: "Jane Smith", email: "jane@example.com", status: "active", joined: "2024-01-14" },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", status: "inactive", joined: "2024-01-13" },
  { id: 4, name: "Alice Brown", email: "alice@example.com", status: "active", joined: "2024-01-12" },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", status: "active", joined: "2024-01-11" },
];

const activityLog = [
  { id: 1, user: "John Doe", action: "Merged PDF", time: "2 minutes ago" },
  { id: 2, user: "Jane Smith", action: "Split PDF", time: "5 minutes ago" },
  { id: 3, user: "Bob Johnson", action: "Compressed PDF", time: "12 minutes ago" },
  { id: 4, user: "Alice Brown", action: "Locked PDF", time: "23 minutes ago" },
  { id: 5, user: "Charlie Wilson", action: "PDF to Image", time: "34 minutes ago" },
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header isAuthenticated isAdmin onLogout={() => console.log("Logout")} />
      <Sidebar isAdmin onLogout={() => console.log("Logout")} />
      
      <main className="flex-1 ml-64 container py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Overview of your PDF utility platform</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpiData.map((kpi, index) => (
            <div key={index} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
              <KPICard {...kpi} />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* User List */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Recent Users</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.status === "active" ? "default" : "secondary"}>
                          {user.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Activity Log */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Activity Log</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activityLog.map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                    <div>
                      <p className="font-medium">{activity.user}</p>
                      <p className="text-sm text-muted-foreground">{activity.action}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
