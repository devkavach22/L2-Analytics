import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Scissors, Upload, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function SplitPDF() {
  const [file, setFile] = useState<File | null>(null);
  const [pageRange, setPageRange] = useState("");
  const { toast } = useToast();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      toast({
        title: "File uploaded",
        description: `${e.target.files[0].name} ready to split`,
      });
    }
  };

  const handleSplit = () => {
    if (!file) {
      toast({
        title: "Error",
        description: "Please select a PDF file first",
        variant: "destructive",
      });
      return;
    }
    toast({
      title: "Splitting PDF",
      description: "Your file is being split...",
    });
    // Split logic would go here
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-hero animate-float">
              <Scissors className="h-10 w-10 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold">Split PDF File</h1>
            <p className="text-xl text-muted-foreground">
              Extract specific pages or split into individual pages
            </p>
          </div>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Upload PDF File</CardTitle>
              <CardDescription>
                Select a PDF file and specify which pages to extract
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-2 border-dashed rounded-lg p-12 text-center hover:border-primary/50 transition-colors">
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <span className="text-primary font-semibold">Choose file</span>
                  {" "}or drag and drop
                  <input
                    id="file-upload"
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                </label>
                <p className="text-sm text-muted-foreground mt-2">PDF files only</p>
              </div>

              {file && (
                <div className="p-4 rounded-lg border bg-card">
                  <p className="font-medium">Selected: {file.name}</p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="pageRange">Page Range (optional)</Label>
                <Input
                  id="pageRange"
                  placeholder="e.g., 1-5, 8, 10-12"
                  value={pageRange}
                  onChange={(e) => setPageRange(e.target.value)}
                />
                <p className="text-sm text-muted-foreground">
                  Leave empty to split into individual pages
                </p>
              </div>

              <Button 
                onClick={handleSplit} 
                disabled={!file}
                className="w-full bg-gradient-hero text-lg py-6"
              >
                <Download className="mr-2 h-5 w-5" />
                Split PDF
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-card bg-muted/50">
            <CardHeader>
              <CardTitle>Split Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-semibold">Split by page range</h4>
                <p className="text-sm text-muted-foreground">
                  Example: "1-5, 8, 10-12" will extract pages 1 through 5, page 8, and pages 10 through 12
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Split all pages</h4>
                <p className="text-sm text-muted-foreground">
                  Leave the page range empty to split the PDF into individual page files
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
