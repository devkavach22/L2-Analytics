import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ToolCard } from "@/components/ToolCard";
import { 
  FileText, 
  Scissors, 
  Lock, 
  Unlock, 
  FileImage, 
  FileDown,
  Zap,
  Shield,
  Clock
} from "lucide-react";

const tools = [
  {
    title: "Merge PDF",
    description: "Combine multiple PDF files into one document seamlessly",
    icon: FileText,
    href: "/tools/merge"
  },
  {
    title: "Split PDF",
    description: "Split your PDF into individual pages or extract specific pages",
    icon: Scissors,
    href: "/tools/split"
  },
  {
    title: "Compress PDF",
    description: "Reduce PDF file size while maintaining quality",
    icon: FileDown,
    href: "/tools/compress"
  },
  {
    title: "Lock PDF",
    description: "Protect your PDF with password encryption",
    icon: Lock,
    href: "/tools/lock"
  },
  {
    title: "Unlock PDF",
    description: "Remove password protection from PDF files",
    icon: Unlock,
    href: "/tools/unlock"
  },
  {
    title: "PDF to Image",
    description: "Convert PDF pages to high-quality images",
    icon: FileImage,
    href: "/tools/pdf-to-image"
  }
];

const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Process your documents in seconds with our optimized tools"
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your files are encrypted and automatically deleted after processing"
  },
  {
    icon: Clock,
    title: "24/7 Available",
    description: "Access our tools anytime, anywhere, from any device"
  }
];

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden bg-gradient-dark">
        <div className="wave-top">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" fill="hsl(var(--background))">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"></path>
          </svg>
        </div>
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center space-y-8 animate-fade-in-up">
            <p className="text-muted-foreground uppercase tracking-wider text-sm">Freshly Roasted</p>
            <h1 className="text-5xl md:text-7xl font-bold leading-tight text-primary-light">
              PDF UTILITY
            </h1>
            <p className="text-xl text-muted-foreground">
              High-end tools. Effortless processing. <span className="font-semibold text-primary-light">Flawless documents, every time.</span>
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button asChild size="lg" className="bg-primary hover:bg-primary-dark text-lg px-8 rounded-full">
                <Link to="/tools">Start Now</Link>
              </Button>
            </div>
          </div>
        </div>
        <div className="wave-bottom">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" fill="hsl(var(--background))">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"></path>
          </svg>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 relative">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-secondary">
            TOP CATEGORIES
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Explore The Recent Most Bought Drinks This Week
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="relative rounded-3xl overflow-hidden shadow-card hover:shadow-hover transition-all duration-300 hover-lift animate-fade-in-up group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="h-64 bg-gradient-dark flex items-center justify-center">
                  <feature.icon className="h-16 w-16 text-primary opacity-50 group-hover:opacity-70 transition-opacity" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-secondary/90 flex flex-col items-center justify-end p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                  <Button variant="secondary" size="sm" className="rounded-full">View More</Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16 bg-card/50">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-secondary">
            TOP PDF TOOLS
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Explore The Recent Most Bought Tools This Week
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {tools.map((tool, index) => (
              <div 
                key={index}
                className="animate-fade-in-up"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <ToolCard {...tool} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 bg-gradient-dark text-primary-foreground overflow-hidden">
        <div className="wave-top">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" fill="hsl(var(--background))">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"></path>
          </svg>
        </div>
        <div className="container text-center space-y-6 relative z-10 mt-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            Ready to optimize your documents?
          </h2>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">
            Join thousands of users who trust Kavach PDF for their document processing needs
          </p>
          <Button asChild size="lg" className="bg-primary hover:bg-primary-dark text-lg px-8 rounded-full">
            <Link to="/auth">Get Started Free</Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
