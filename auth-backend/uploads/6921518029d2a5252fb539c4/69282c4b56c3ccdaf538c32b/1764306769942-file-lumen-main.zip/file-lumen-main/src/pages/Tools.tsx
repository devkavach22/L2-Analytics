import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ToolCard } from "@/components/ToolCard";
import { 
  FileText, 
  Scissors, 
  Lock, 
  Unlock, 
  FileImage, 
  FileDown,
  RotateCw,
  Wand2
} from "lucide-react";

const tools = [
  {
    title: "Merge PDF",
    description: "Combine multiple PDF files into one document seamlessly",
    icon: FileText,
    href: "/tools/merge"
  },
  {
    title: "Split PDF",
    description: "Split your PDF into individual pages or extract specific pages",
    icon: Scissors,
    href: "/tools/split"
  },
  {
    title: "Compress PDF",
    description: "Reduce PDF file size while maintaining quality",
    icon: FileDown,
    href: "/tools/compress"
  },
  {
    title: "Lock PDF",
    description: "Protect your PDF with password encryption",
    icon: Lock,
    href: "/tools/lock"
  },
  {
    title: "Unlock PDF",
    description: "Remove password protection from PDF files",
    icon: Unlock,
    href: "/tools/unlock"
  },
  {
    title: "PDF to Image",
    description: "Convert PDF pages to high-quality images",
    icon: FileImage,
    href: "/tools/pdf-to-image"
  },
  {
    title: "Rotate PDF",
    description: "Rotate PDF pages to the correct orientation",
    icon: RotateCw,
    href: "/tools/rotate"
  },
  {
    title: "Optimize PDF",
    description: "Optimize PDF for web viewing and faster loading",
    icon: Wand2,
    href: "/tools/optimize"
  }
];

export default function Tools() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container py-12">
        <div className="text-center space-y-4 mb-12">
          <h1 className="text-4xl font-bold">
            All <span className="gradient-text">PDF Tools</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Choose from our comprehensive suite of PDF utilities to process your documents
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <div 
              key={index}
              className="animate-fade-in-up"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <ToolCard {...tool} />
            </div>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}
