import { Header } from "@/components/Header";
import { Sidebar } from "@/components/Sidebar";
import { Footer } from "@/components/Footer";
import { KPICard } from "@/components/KPICard";
import { FileText, Clock, Download, Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const userStats = [
  {
    title: "Documents Processed",
    value: "47",
    icon: FileText,
    trend: { value: 15.3, isPositive: true }
  },
  {
    title: "Hours Saved",
    value: "12.5",
    icon: Clock,
    trend: { value: 8.7, isPositive: true }
  },
  {
    title: "Total Downloads",
    value: "89",
    icon: Download,
    trend: { value: 23.1, isPositive: true }
  },
  {
    title: "Favorites",
    value: "8",
    icon: Star,
  }
];

const recentFiles = [
  { id: 1, name: "Contract_merged.pdf", tool: "Merge PDF", date: "2 hours ago", size: "2.4 MB" },
  { id: 2, name: "Report_compressed.pdf", tool: "Compress PDF", date: "5 hours ago", size: "1.2 MB" },
  { id: 3, name: "Invoice_split.pdf", tool: "Split PDF", date: "1 day ago", size: "856 KB" },
  { id: 4, name: "Document_locked.pdf", tool: "Lock PDF", date: "2 days ago", size: "3.1 MB" },
  { id: 5, name: "Presentation_images.zip", tool: "PDF to Image", date: "3 days ago", size: "4.5 MB" },
];

export default function UserDashboard() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header isAuthenticated onLogout={() => console.log("Logout")} />
      <Sidebar onLogout={() => console.log("Logout")} />
      
      <main className="flex-1 ml-64 container py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Welcome back!</h1>
          <p className="text-muted-foreground">Here's an overview of your document activity</p>
        </div>

        {/* User Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {userStats.map((stat, index) => (
            <div key={index} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
              <KPICard {...stat} />
            </div>
          ))}
        </div>

        {/* Recent Files */}
        <Card className="shadow-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Files</CardTitle>
            <Button variant="outline" size="sm">View All</Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentFiles.map((file) => (
                <div 
                  key={file.id} 
                  className="flex items-center justify-between p-4 rounded-lg border hover:border-primary/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-hero">
                      <FileText className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="font-medium">{file.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">{file.tool}</Badge>
                        <span className="text-xs text-muted-foreground">{file.date}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">{file.size}</p>
                    <Button variant="ghost" size="sm" className="mt-1">
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="shadow-card bg-gradient-card">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="bg-gradient-hero h-auto py-6 flex-col gap-2">
                <FileText className="h-6 w-6" />
                <span>Merge PDF</span>
              </Button>
              <Button variant="outline" className="h-auto py-6 flex-col gap-2">
                <Download className="h-6 w-6" />
                <span>Compress PDF</span>
              </Button>
              <Button variant="outline" className="h-auto py-6 flex-col gap-2">
                <Clock className="h-6 w-6" />
                <span>View History</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}
