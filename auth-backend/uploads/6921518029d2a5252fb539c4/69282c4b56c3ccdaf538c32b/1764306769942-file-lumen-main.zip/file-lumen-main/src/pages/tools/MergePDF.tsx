import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Upload, Download, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function MergePDF() {
  const [files, setFiles] = useState<File[]>([]);
  const { toast } = useToast();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles([...files, ...newFiles]);
      toast({
        title: "Files added",
        description: `${newFiles.length} file(s) added successfully`,
      });
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleMerge = () => {
    if (files.length < 2) {
      toast({
        title: "Error",
        description: "Please select at least 2 PDF files to merge",
        variant: "destructive",
      });
      return;
    }
    toast({
      title: "Merging PDFs",
      description: "Your files are being merged...",
    });
    // Merge logic would go here
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-hero animate-float">
              <FileText className="h-10 w-10 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold">Merge PDF Files</h1>
            <p className="text-xl text-muted-foreground">
              Combine multiple PDF documents into one file
            </p>
          </div>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Upload PDF Files</CardTitle>
              <CardDescription>
                Select multiple PDF files to merge them into a single document
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-2 border-dashed rounded-lg p-12 text-center hover:border-primary/50 transition-colors">
                <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <span className="text-primary font-semibold">Choose files</span>
                  {" "}or drag and drop
                  <input
                    id="file-upload"
                    type="file"
                    accept=".pdf"
                    multiple
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                </label>
                <p className="text-sm text-muted-foreground mt-2">PDF files only</p>
              </div>

              {files.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-semibold">Selected Files ({files.length})</h3>
                  {files.map((file, index) => (
                    <div 
                      key={index}
                      className="flex items-center justify-between p-4 rounded-lg border bg-card"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5 text-primary" />
                        <span className="font-medium">{file.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFile(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <Button 
                onClick={handleMerge} 
                disabled={files.length < 2}
                className="w-full bg-gradient-hero text-lg py-6"
              >
                <Download className="mr-2 h-5 w-5" />
                Merge PDF Files
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-card bg-muted/50">
            <CardHeader>
              <CardTitle>How it works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold flex-shrink-0">
                  1
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Upload your files</h4>
                  <p className="text-sm text-muted-foreground">
                    Select multiple PDF files you want to combine
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold flex-shrink-0">
                  2
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Arrange files</h4>
                  <p className="text-sm text-muted-foreground">
                    Drag and drop to reorder your files if needed
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold flex-shrink-0">
                  3
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Download merged PDF</h4>
                  <p className="text-sm text-muted-foreground">
                    Click merge and download your combined PDF file
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
