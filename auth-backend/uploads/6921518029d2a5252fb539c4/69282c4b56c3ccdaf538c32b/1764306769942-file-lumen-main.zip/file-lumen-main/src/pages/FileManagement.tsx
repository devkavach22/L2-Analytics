import { Header } from "@/components/Header";
import { Sidebar } from "@/components/Sidebar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FileText, Search, Filter, Download, Trash2, Eye } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const files = [
  { 
    id: 1, 
    name: "Annual_Report_2024.pdf", 
    size: "3.2 MB", 
    modified: "2024-01-15",
    type: "Merged",
    status: "Completed"
  },
  { 
    id: 2, 
    name: "Contract_Agreement.pdf", 
    size: "1.8 MB", 
    modified: "2024-01-14",
    type: "Locked",
    status: "Completed"
  },
  { 
    id: 3, 
    name: "Presentation_Slides.pdf", 
    size: "5.4 MB", 
    modified: "2024-01-13",
    type: "Compressed",
    status: "Completed"
  },
  { 
    id: 4, 
    name: "Invoice_January.pdf", 
    size: "856 KB", 
    modified: "2024-01-12",
    type: "Split",
    status: "Completed"
  },
  { 
    id: 5, 
    name: "Marketing_Plan.pdf", 
    size: "2.1 MB", 
    modified: "2024-01-11",
    type: "Optimized",
    status: "Completed"
  },
  { 
    id: 6, 
    name: "Project_Documentation.pdf", 
    size: "4.7 MB", 
    modified: "2024-01-10",
    type: "Merged",
    status: "Processing"
  },
];

export default function FileManagement() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header isAuthenticated onLogout={() => console.log("Logout")} />
      <Sidebar onLogout={() => console.log("Logout")} />
      
      <main className="flex-1 ml-64 container py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">File Management</h1>
            <p className="text-muted-foreground">Manage all your processed documents</p>
          </div>
          <Button className="bg-gradient-hero">
            <FileText className="mr-2 h-4 w-4" />
            Upload New
          </Button>
        </div>

        {/* Search and Filter */}
        <Card className="shadow-card">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Search files..." 
                  className="pl-10"
                />
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    <Filter className="mr-2 h-4 w-4" />
                    Filter
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>All Files</DropdownMenuItem>
                  <DropdownMenuItem>Merged</DropdownMenuItem>
                  <DropdownMenuItem>Split</DropdownMenuItem>
                  <DropdownMenuItem>Compressed</DropdownMenuItem>
                  <DropdownMenuItem>Locked</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardContent>
        </Card>

        {/* Files Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {files.map((file, index) => (
            <Card 
              key={file.id} 
              className="hover-lift shadow-card animate-fade-in-up"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-hero flex-shrink-0">
                      <FileText className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base truncate">{file.name}</CardTitle>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {file.type}
                        </Badge>
                        <Badge 
                          variant={file.status === "Completed" ? "default" : "outline"}
                          className="text-xs"
                        >
                          {file.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <span>{file.size}</span>
                  <span>{file.modified}</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="mr-1 h-4 w-4" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="mr-1 h-4 w-4" />
                    Download
                  </Button>
                  <Button variant="outline" size="sm">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}
